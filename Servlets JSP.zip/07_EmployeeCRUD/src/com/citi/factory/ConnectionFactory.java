package com.citi.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {

	private String driver = "com.mysql.cj.jdbc.Driver";
	private String url = "jdbc:mysql://localhost:3306/citidb";
	private String user = "root";
	private String password = "Trupt!V!vek@143";

	public Connection getConnection() {
		try {
			Class.forName(driver);
			Connection connection = DriverManager.getConnection(url, user, password);
			if (connection != null)
				return connection;
		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
		} catch (SQLException e) {
			System.out.println("Connection Failed");
			System.out.println(e.getMessage());
		}
		return null;
	}
}
