package com.citi.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.citi.factory.ConnectionFactory;
import com.citi.pojo.Employee;

public class EmployeeDAO {

	private Connection connection;
	private ConnectionFactory factory;
	private PreparedStatement preparedStatement;
	private ResultSet resultset;
	private List<Employee> employeeList;

	private int count;
	private String query;

	public boolean addNewEmployee(Employee employee) {
		try {
			factory = new ConnectionFactory();
			connection = factory.getConnection();
			if (connection != null) {
				query = "insert into employee_master values(?,?,?)";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, employee.getEmployeeId());
				preparedStatement.setString(2, employee.getName());
				preparedStatement.setDouble(3, employee.getSalary());

				count = preparedStatement.executeUpdate();

				if (count > 0) {
					System.out.println("Recored inserted successfully !!");
					return true;
				} else
					return false;
			}
		} catch (SQLException e) {
			System.out.println("Exception");
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception");
				System.out.println(e.getMessage());
			}
		}
		return false;
	}

	public List<Employee> getAllEmployees() {
		System.out.println("in getAllEmployees()");
		try {
			factory = new ConnectionFactory();
			connection = factory.getConnection();
			if (connection != null) {
				query = "select * from employee_master";
				preparedStatement = connection.prepareStatement(query);

				resultset = preparedStatement.executeQuery();
				employeeList = new ArrayList<Employee>();
				while (resultset.next()) {
					Employee employee = new Employee();

					employee.setEmployeeId(resultset.getInt("employee_Id"));
					employee.setName(resultset.getString("name"));
					employee.setSalary(resultset.getDouble("salary"));
					System.out.println(employee);

					employeeList.add(employee);

				}
				return employeeList;
			}

		} catch (SQLException e) {
			System.out.println("Exception");
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception");
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

	public boolean deleteEmployee(int employeeId) {
		try {
			factory = new ConnectionFactory();
			connection = factory.getConnection();
			if (connection != null) {
				query = "delete from employee_master where employee_id = ?";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, employeeId);

				count = preparedStatement.executeUpdate();

				if (count > 0) {
					System.out.println("Recored deleted successfully !!");
					return true;
				} else
					return false;
			}
		} catch (SQLException e) {
			System.out.println("Exception");
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception");
				System.out.println(e.getMessage());
			}
		}
		return false;
	}

	public Employee getEmployee(int employeeId) {
		System.out.println("in getEmployee()");
		try {
			factory = new ConnectionFactory();
			connection = factory.getConnection();
			if (connection != null) {
				query = "select * from employee_master where employee_id = ?";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, employeeId);

				resultset = preparedStatement.executeQuery();
				Employee employee = null;
				if (resultset.next()) {

					employee = new Employee();

					employee.setEmployeeId(resultset.getInt("employee_Id"));
					employee.setName(resultset.getString("name"));
					employee.setSalary(resultset.getDouble("salary"));
					System.out.println(employee);

				}
				return employee;
			}

		} catch (SQLException e) {
			System.out.println("Exception");
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception");
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

	public boolean updateEmployee(Employee employee) {
		try {
			factory = new ConnectionFactory();
			connection = factory.getConnection();
			if (connection != null) {
				query = "update employee_master set name = ? , salary = ? where employee_id = ?";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(3, employee.getEmployeeId());
				preparedStatement.setString(1, employee.getName());
				preparedStatement.setDouble(2, employee.getSalary());

				count = preparedStatement.executeUpdate();

				if (count > 0) {
					System.out.println("Recored updated successfully !!");
					return true;
				} else
					return false;
			}
		} catch (SQLException e) {
			System.out.println("Exception");
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception");
				System.out.println(e.getMessage());
			}
		}
		return false;
	}
}
