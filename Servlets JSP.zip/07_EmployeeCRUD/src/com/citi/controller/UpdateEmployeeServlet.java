package com.citi.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.citi.dao.EmployeeDAO;
import com.citi.pojo.Employee;

/**
 * Servlet implementation class UpdateEmployeeServlet
 */
public class UpdateEmployeeServlet extends HttpServlet {

	private int employeeId;
	private String name;
	private double salary;
	private EmployeeDAO dao;
	private HttpSession session;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			dao = new EmployeeDAO();
			session = request.getSession();

			employeeId = Integer.valueOf(request.getParameter("employeeId"));
			name = request.getParameter("txtName");
			salary = Double.valueOf(request.getParameter("txtSalary"));

			Employee employee = new Employee(employeeId, name, salary);

			if (dao.updateEmployee(employee)) {
				session.setAttribute("message", "<h5>Employee updated successfully.</h5>");
				response.sendRedirect("AllEmployees.jsp");
			} else {
				session.setAttribute("message", "<h5>Invalid Details</h5>");
				response.sendRedirect("updateEmployeeDetails.jsp");
			}
		} catch (Exception e) {
			session.setAttribute("message", "<h5>Invalid Details</h5>");
			response.sendRedirect("updateEmployeeDetails.jsp");
		}

	}

}
