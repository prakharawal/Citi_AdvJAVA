package com.citi.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.citi.dao.EmployeeDAO;
import com.citi.pojo.Employee;

public class AddNewEmployeeServlet extends HttpServlet {

	private int employeeId;
	private String name;
	private double salary;
	private Employee employee;
	private EmployeeDAO employeeDAO;
	private HttpSession session;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		session = request.getSession();
		employeeId = Integer.valueOf(request.getParameter("txtEmployeeId"));
		name = request.getParameter("txtName");
		salary = Double.valueOf(request.getParameter("txtSalary"));

		employee = new Employee(employeeId, name, salary);

		System.out.println(employee);

		employeeDAO = new EmployeeDAO();
		if (employeeDAO.addNewEmployee(employee)) {
			session.setAttribute("message", "<h5>Employee added successfully !</h5>");
			response.sendRedirect("AllEmployees.jsp");
		} else {
			session.setAttribute("message", "<h5>Failed to add Employee !</h5>");
			response.sendRedirect("addNewEmployee.jsp");
		}

	}

}
