package com.citi.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.citi.dao.EmployeeDAO;
import com.citi.pojo.Employee;

/**
 * Servlet implementation class NavigationServlet
 */
public class NavigationServlet extends HttpServlet {

	private String path;
	private int employeeId;
	private EmployeeDAO dao;
	private HttpSession session;
	private Employee employee;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		dao = new EmployeeDAO();
		session = request.getSession();

		if (request.getParameter("navigation") != null) {
			path = request.getParameter("navigation");
			switch (path) {
			case "New Employee":
				response.sendRedirect("addNewEmployee.jsp");
				break;
			case "Delete":
				if (request.getParameter("rdoEmployee") != null) {
					employeeId = Integer.valueOf(request.getParameter("rdoEmployee"));
					if (dao.deleteEmployee(employeeId)) {
						session.setAttribute("message", "<h5>Employee deleted successfully.</h5>");
						response.sendRedirect("AllEmployees.jsp");
					}
				} else {
					session.setAttribute("message", "<h5>Please make valid selection.</h5>");
					response.sendRedirect("AllEmployees.jsp");
				}
				break;
			case "Update":
				if (request.getParameter("rdoEmployee") != null) {
					employeeId = Integer.valueOf(request.getParameter("rdoEmployee"));
					employee = dao.getEmployee(employeeId);
					if (employee != null) {
						System.out.println(employee);
						session.setAttribute("employee", employee);
						response.sendRedirect("updateEmployeeDetails.jsp");
					}
				} else {
					session.setAttribute("message", "<h5>Please make valid selection.</h5>");
					response.sendRedirect("AllEmployees.jsp");
				}
				break;

			}
		} else {
			session.setAttribute("message", "<h5>Please make valid selection.</h5>");
		}
	}

}
