package com.citi.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.citi.pojo.UserDetails;

public class ValidateUserServlet extends HttpServlet {

	private String userId, password;
	private HttpSession session;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		session = request.getSession();

		userId = request.getParameter("txtLoginId");
		password = request.getParameter("txtPassword");

		UserDetails details = (UserDetails) session.getAttribute("userDetails");
		if (details != null) {

			if (details.getUserId().equals(userId) && details.getPassword().equals(password)) {
				response.sendRedirect("UserHomeServlet");
			} else {
				response.sendRedirect("loginFailed.html");
			}
		} else
			response.sendRedirect("loginFailed.html");
	}

}
