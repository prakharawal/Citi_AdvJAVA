package com.citi.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.citi.pojo.UserDetails;

public class SigninServlet extends HttpServlet {

	private PrintWriter out;
	private String name, userId, password;
	private HttpSession session;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		out = response.getWriter();
		session = request.getSession();

		name = request.getParameter("txtName");
		userId = request.getParameter("txtUserId");
		password = request.getParameter("txtPassword");

		// option 1
//		session.setAttribute("name", name);
//		session.setAttribute("userId", userId);
//		session.setAttribute("password", password);

		// option 2
		UserDetails details = new UserDetails(name, userId, password);
		session.setAttribute("userDetails", details);

		out.println("<h3>User created successfully !!</h3>");
		out.println("<br>");
		out.println("<a href=login.html>Login</a>");

	}

}
