package com.citi.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.citi.pojo.UserDetails;

public class UserHomeServlet extends HttpServlet {

	private PrintWriter out;
	private HttpSession session;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		out = response.getWriter();
		session = request.getSession();

		UserDetails details = (UserDetails) session.getAttribute("userDetails");

		out.println("<h3>Welcome " + details.getUserName() + "</h3>");
		out.println("<br>");
		out.println("<a href=LogoutServlet>Logout</a>");
	}

}
