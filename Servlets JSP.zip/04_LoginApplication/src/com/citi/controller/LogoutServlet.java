package com.citi.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LogoutServlet extends HttpServlet {

	private HttpSession session;
	private PrintWriter out;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		session = request.getSession();
		out = response.getWriter();

		// delete everyting from session
		session.invalidate();

		// delete a attribute from session
		// session.removeAttribute("userDetails");

		out.println("Logout Success !!");
		out.println("<br>");
		out.println("<a href=login.html>Login</a>");

	}

}
