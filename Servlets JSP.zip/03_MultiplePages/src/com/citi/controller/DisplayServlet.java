package com.citi.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class DisplayServlet extends HttpServlet {

	private PrintWriter out;
	private String name, address;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		out = response.getWriter();
		name = "No Cookie found !!";
		/*
		 * // reading data from cookie Cookie[] cookies = request.getCookies();
		 * 
		 * for (Cookie cookie : cookies) { if (cookie.getName().equals("userName")) name
		 * = cookie.getValue(); }
		 */
		
		HttpSession session = request.getSession();
		name = session.getAttribute("userName").toString();
		
		address = request.getParameter("txtAddress");

		out.println("<h3>Hello " + name + "</h3>");
		out.println("<h3>Address ::  " + address + "</h3>");
	}

}
