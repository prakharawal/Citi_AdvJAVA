package com.citi.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class PageOneServlet extends HttpServlet {

	private String name;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		name = request.getParameter("txtName");

		// create cookie
		/*
		 * Cookie cookie = new Cookie("userName", name);
		 * 
		 * cookie.setMaxAge(60*60*24);
		 * 
		 * response.addCookie(cookie);
		 */

		HttpSession session = request.getSession();
		session.setAttribute("userName", name);

		response.sendRedirect("pageTwo.html");
	}

}
