package com.citi.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserDetailFormServlet extends HttpServlet {

	private PrintWriter out;
	private String name, gender, qualification;
	private int age;
	private String[] languages;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		out = response.getWriter();
		name = request.getParameter("txtName");
		age = Integer.valueOf(request.getParameter("txtAge"));
		gender = request.getParameter("rdoGender");
		qualification = request.getParameter("ddlQualification");
		languages = request.getParameterValues("ckbLanguage");

		out.println("Name :: " + name);
		out.println("Age :: " + age);
		out.println("Gender :: " + gender);
		out.println("qualification :: " + qualification);
		out.println("List of Languages :: ");
		for (String language : languages) {
			out.println(language);
		}

	}

}
