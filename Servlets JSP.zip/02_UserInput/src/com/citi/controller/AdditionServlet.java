package com.citi.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AdditionServlet extends HttpServlet {

	private double num1, num2, result;
	private PrintWriter out;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		out = response.getWriter();
		out.println("doGet is called");
		num1 = Double.valueOf(request.getParameter("txtNumOne"));
		num2 = Double.valueOf(request.getParameter("txtNumTwo"));

		result = num1 + num2;

		out.println("Addition of " + num1 + " and " + num2 + " is " + result);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		out = response.getWriter();
		out.println("doPost is called");
		num1 = Double.valueOf(request.getParameter("txtNumOne"));
		num2 = Double.valueOf(request.getParameter("txtNumTwo"));

		result = num1 + num2;
	

		out.println("Addition of " + num1 + " and " + num2 + " is " + result);
	}
}
